# mandos

**M**aking and **AN**alysing **D**endrograms from **O**ccurrences in **S**tratigraphy
