import tree_utils
import tree_reader
import math
from scipy import optimize
import random
import sys

LARGE = 10000000000

def hr97_loglike(tree,lam):
    treelik =0
    for i in tree.iternodes(order = 1):
        if i == tree:
            continue
        tf = i.parent.height
        tl = i.height
        nfos = i.num_occurrences
        if nfos > 1:
            f = max(i.occurrences)
            l = min(i.occurrences)
            a = math.log(math.pow(f-l,(nfos-2)))
            b = math.log(math.pow(lam,nfos))
            c = -lam*(tf-tl)
            top = a+b+c
            bot = math.log(math.factorial(nfos-2))
            brlik = top-bot
            #print brlik
            #brlik= math.log((math.pow((f-l),(nfos-2))*math.pow(lam,nfos)*math.exp(-lam*(tf-tl)))/(math.factorial(nfos-2)))
            #print brlik
        elif nfos == 1:
            brlik = math.log(lam)+(-lam*(tf-tl))
        elif i.occurrences[0] == "NA" or i.occurrences == None:
            brlik = math.log(lam)+math.log((tf-tl))
        treelik += brlik
    return treelik

def calc_like_strat(p,tree,strat): #p[0] should be lambda, p[1:] is node heights
    for i in p:
        if i < 0:
            return LARGE
    bad = tree_utils.assign_node_heights(p[1:],tree)
    if bad:
        return LARGE
    try:
        val = -hr97_loglike(tree,p[0])
    except:
        return LARGE
    return val

def optim_lambda_heights(tree,strat):
    tree_utils.assign_node_nums(tree)
    start = [random.uniform(0.0001,1)]
    start += [i.height for i in tree.iternodes(order = 0)]#if i.istip == False]
    #print "start optim", tree.get_newick_repr(True),hr97_loglike(tree,start[0])
    opt = optimize.fmin_powell(calc_like_strat,start,args=(tree,strat),full_output = True, disp = True)
    #print "done optim", tree.get_newick_repr(True)
    tree_utils.assign_node_heights(opt[0][1:],tree)
    #print "done optim",tree.get_newick_repr(True),hr97_loglike(tree,opt[0][0])
    #sys.exit(0)
    return [tree,opt]

def collapse_non_overlapping_ranges(tree):
    for i in tree.iternodes(order = 0):
        children= i.children 
        ranges = [j.occurrences for j in children]
        if len(i.children)<2:
            continue
        if "NA" in ranges[0] and "NA" in ranges[1] or i.istip:
            continue
        elif "NA" in ranges[0]:
            if min(ranges[1]) > children[0].height:
                i.occurrences = ranges[1]
                i.num_occurrences = children[1].num_occurrences
                i.height = children[1].height
                i.length += children[1].length
                children[0].length -= children[1].length
                i.label = children[1].label
                i.remove_child(children[1])
        elif "NA" in ranges[1]:
            if min(ranges[0]) > children[1].height:
                i.occurrences = ranges[0]
                i.num_occurrences = children[0].num_occurrences
                i.height = children[0].height
                i.length += children[0].length
                children[1].length -= children[0].length
                i.label = children[0].label
                i.remove_child(children[0])
        else:
            if min(ranges[0])>max(ranges[1]):
                i.occurrences= ranges[0]
                i.num_occurrences = children[0].num_occurrences
                i.height = children[0].height
                i.length +=children[0].length
                children[1].length -= children[0].length
                i.label = children[0].label
                i.remove_child(children[0])
                #print [j.label for j in children]
            elif min(ranges[1]) > max(ranges[0]):
                i.occurrences= ranges[1]
                i.num_occurrences = children[1].num_occurrences
                i.height = children[1].height
                i.length +=children[1].length
                children[0].length -= children[1].length
                i.label = children[1].label
                i.remove_child(children[1])
    for i in tree.iternodes():
        if i.parent == None:
            continue
        #print i.label
        #print i.parent.label
    print tree.get_newick_repr(True)
    """
    print ranges
    if ranges == None:
        continue
    if "NA" in ranges[0] or "NA" in ranges[1] or i.istip:
       continue 
    if min(ranges[0]) > max(ranges[1]):
        i.length = i.length + i.children[0].length#-0.0000001
        i.children[0].length = 0.0# 0.0000001
        i.height = i.children[0].height #+ 0.0000001
    elif min(ranges[1]) > max(ranges[0]):
        i.length = i.length + i.children[0].length#-0.0000001
        i.children[0].length = 0.0# 0.0000001
        i.height = i.children[0].height #+ 0.0000001
    """















