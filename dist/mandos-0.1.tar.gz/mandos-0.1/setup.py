long_description = "Mandos provides tools for measuring the fit of phylogenies to the stratographic record and hypothesis-testing of direct ancestorship."

from setuptools import setup, find_packages


#def readme():
#    with open('README.rst') as f:
#        return f.read()


setup(name='mandos',
      version='0.1',
      description='Phylogenetic analysis of stratigraphic occurrences and morphology',
      long_description=long_description,
      classifiers=[
        'Development Status :: 3 - Alpha',
        'License :: OSI Approved :: GPL License',
        'Programming Language :: Python :: 2.7'
      ],
      keywords='',
      url='http://github.com/carolinetomo/mandos',
      author='Caroline Parins-Fukuchi',
      author_email='cfukuchi@umich.edu',
      license='GPL',
      packages=find_packages(exclude = ['scripts','tests']),#['mandos'],
      #entry_points = {'console_scripts':['search-mandos-trees = mandos.command_line:main'],},
      #package_data = `
      #include_package_data= True,
      install_requires=[
          'scipy',
      ],
      zip_safe=False)
